class Profile:
    def __init__(self, profileID, address, contactNumber):
        self.__profileID = profileID
        self.__address = address
        self.__contactNumber = contactNumber

    # Getter
    def get_profileID(self):
        return self.__profileID
    
    def get_address(self):
        return self.__address
    
    def get_contactNumber(self):
        return self.__contactNumber
    
    # Setter Methods
    def set_address(self, new_address):                # Updates the address safely
        if not new_address.strip():
            print("Address cannot be empty.")
            return
        self.__address = new_address
        print(f"Address updated to: {new_address}")

    def set_contactNumber(self, new_contact):          # Updates the contact number safely
        if not new_contact.isdigit():
            print("Invalid contact number. It must contain digits only.")
            return
        self.__contactNumber = new_contact
        print(f"Contact number updated to: {new_contact}")

    # Behaviour Methods
    def updateProfile(self, new_address=None, new_contact=None):
        if new_address:
            self.set_address(new_address)
        if new_contact:
            self.set_contactNumber(new_contact)
        print("Profile updated.")

    def updatePassword(self):
        print("Profile password updated.")

#Class Profile
#Implemented by Vanessa Mennie Anak Jeffery
#103005