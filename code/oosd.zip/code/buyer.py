from user import User

class Buyer(User):
    def __init__(self, userID, name, email, password, buyerID):
        # INHERITANCE: Calling the parent constructor
        super().__init__(userID, name, email, password)
        self.__buyerID = buyerID

    # Getter to access private buyerID
    def get_buyerID(self):
        return self.__buyerID

    # Behaviour Methods
    def placeOrder(self, orderID):
        # This matches TC-01 requirements
        print("New order placed by Buyer.")
        return True

    def cancelOrder(self):
        print("Order cancelled")

    def viewOrder(self):
        print("Viewing current order.")

    def viewPaymentHistory(self):
        print("Viewing payment history.")

    def settlePayment(self):
        print("Payment settled.")

    def processPayment(self):
        # This matches TC-05 requirements
        print("Payment processed.")

#Class Buyer
#Implemented by Zechariah Vieri Anak Sari
#106772