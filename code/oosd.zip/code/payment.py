class Payment:
    def __init__(self, paymentID, paymentDate, amount):
        self.__paymentID = paymentID
        self.__paymentDate = paymentDate
        self.__amount = amount
        self.__paymentStatus = "Pending"     # Initial status

    # Getter
    def get_paymentID(self):
        return self.__paymentID
    
    def get_paymentDate(self):
        return self.__paymentDate
    
    def get_amount(self):
        return self.__amount
    
    def get_paymentStatus(self):
        return self.__paymentStatus

    # Behaviour methods
    def processPayment(self):      
        self.__paymentStatus = "Payment Processed"
        print(f"Payment {self.__paymentID} processed successfully.")
        print(f"Amount: RM{self.__amount:.2f}")
        print(f"Payment Date: {self.__paymentDate}")
        print(f"Payment Status: {self.__paymentStatus}")

    def settlePayment(self):
        if self.__paymentStatus == "Settled":
            print(f"Payment {self.__paymentID} is already settled.")
        else:
            self.__paymentStatus = "Settled"
            print(f"Payment {self.__paymentID} settled successfully.")

#Class Payment
#Implemented by Mohammad Nabil Aiman bin Abdullah Abaang Safian
#105072