from user import User

class Driver(User):
    def __init__(self, userID, name, email, password, driverID, vehicleDetails):
        super().__init__(userID, name, email, password)
        self.__driverID = driverID
        self.__vehicleDetails = vehicleDetails

    # Getter
    def get_driverID(self):
        return self.__driverID
    
    def get_vehicleDetails(self):
        return self.__vehicleDetails
    
    #Behaviour Methods

    def calculateTransportCost(self):
        print("Transport cost calculated.")

    def confirmDelivery(self):
        print("Delivery confirmed.")

#Class Driver
#Zechariah Vieri Anak Sari
#106772