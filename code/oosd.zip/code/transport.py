class Transport:
    def __init__(self, transportID, distance, costPerKm):
        self.__transportID = transportID
        self.__distance = distance
        self.__costPerKm = costPerKm

    # Getter
    def get_transportID(self):
        return self.__transportID
    
    def get_distance(self):
        return self.__distance
    
    def get_costPerKm(self):
        return self.__costPerKm

    # Behaviour Method
    def calculateCost(self):
        print("Transport cost calculated.")

#Class Transport
#Implemented by Mohammad Nabil Aiman bin Abdullah Abaang Safian
#105072