import os
import sys
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USER_DATA_FILE = os.path.join(BASE_DIR, "users.txt")
sys.path.append(BASE_DIR)

from farmer import Farmer
from buyer import Buyer
from coordinator import Coordinator
from driver import Driver
from payment import Payment
from produce import Produce 

import buyermenu
import farmermenu
import coordinatormenu
import drivermenu


registered_users = {}

# ================= FILE HANDLING =================

def save_to_txt():
    try:
        with open(USER_DATA_FILE, "w") as f:
            for user_id, info in registered_users.items():
                for role_key, role_data in info['roles'].items():
                    # Standard common user info
                    line = f"{info['user_id']}|{info['name']}|{info['email']}|{info['password']}|{role_key}|{role_data['role_id']}"
                    
                    role_obj = role_data['role_object']

                    # Using Getters for private attributes (Encapsulation)
                    if role_key == "3": # Driver
                        line += f"|{role_obj.get_vehicleDetails()}"
                    elif role_key == "4": # Farmer
                        line += f"|{role_obj.getFarmName()}|{role_obj.getLocation()}"
                    
                    f.write(line + "\n")
        print(f"\n[SYSTEM] Data successfully saved to {USER_DATA_FILE}.")
    except Exception as e: 
        print(f"\n[SYSTEM ERROR] Error saving to file: {e}")

def load_from_txt():
    """Loads user data from users.txt and reconstructs objects"""
    global registered_users
    try:
        with open(USER_DATA_FILE, "r") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) >= 6:
                    u_id, name, email, pwd, r_key, r_id = parts[:6]
                    user_obj = None
                    
                    if r_key == "1": user_obj = Coordinator(u_id, name, email, pwd, r_id)
                    elif r_key == "2": user_obj = Buyer(u_id, name, email, pwd, r_id)
                    elif r_key == "3": user_obj = Driver(u_id, name, email, pwd, r_id, parts[6])
                    elif r_key == "4": user_obj = Farmer(u_id, name, email, pwd, r_id, parts[6], parts[7])
                    
                    if u_id not in registered_users:
                        registered_users[u_id] = {'user_id': u_id, 'name': name, 'email': email, 'password': pwd, 'roles': {}}
                    
                    role_map = {"1": "Coordinator", "2": "Buyer", "3": "Driver", "4": "Farmer"}
                    registered_users[u_id]['roles'][r_key] = {
                        'role_name': role_map[r_key], 
                        'role_id': r_id, 
                        'role_object': user_obj
                    }
    except FileNotFoundError: 
        pass

# ================= TEST MODULES =================

def test_buyer_cases(buyer_obj):
    """Specific menu for TC-01, TC-05, and TC-06 with Manual Inputs"""
    while True:
        print("\n=== BUYER TEST MODULE ===")
        print("1. [TC-01] Place New Order")
        print("2. [TC-05] Process Payment")
        print("3. [TC-06] Calculate Price")
        print("0. Exit Test Module")
        
        t_choice = input("\nSelect Test: ").strip()
        
        if t_choice == "1":
            order_id = input("Enter Order ID (e.g., 001): ").strip()
            buyer_obj.placeOrder(order_id)
            
        elif t_choice == "2":
            pay_id = input("Enter Payment ID (e.g., P-99): ").strip()
            try:
                amt = float(input("Enter Amount (e.g. 1500): RM"))
                pay = Payment(pay_id, "2026-01-06", amt)
                pay.processPayment()
            except ValueError: 
                print("[ERROR] Invalid numeric input for amount.")

        elif t_choice == "3":
            print("\n--- [TC-06] Price Overloading Test ---")
            prod = Produce("P01", "Durian", "A", 0, 5.0) 
            try:
                print("\n[Scenario A: Base Calculation]")
                w_a = float(input("Enter Weight (kg)(e.g. 10): "))
                prod.calculatePrice(weight=w_a) 
                
                print("\n[Scenario B: Discount Calculation]")
                w_b = float(input("Enter Weight (kg)(e.g. 10): "))
                d_b = float(input("Enter Discount (RM)(e.g.10): "))
                prod.calculatePrice(weight=w_b, discount=d_b)
                
                print("\nPrices calculated correctly for both scenarios.")
            except ValueError: 
                print("[ERROR] Invalid input for weight or discount.")
            
        elif t_choice == "0": 
            break

# ================= CORE FUNCTIONS =================

def signup():
    print("\n=== NEW USER SIGN UP ===")
    user_id = input("Enter User ID: ").strip()
    name = input("Enter Full Name: ").strip()
    email = input("Enter Email: ").strip()
    password = input("Enter Password: ").strip()
    
    print("\nAvailable Roles:")
    print("1. Coordinator")
    print("2. Buyer")
    print("3. Driver")
    print("4. Farmer")
    print("5. Cancel and Return")
    
    choice = input("\nSelect Role (1-5): ").strip()
    if choice == "5": return
    
    role_map = {"1": "Coordinator", "2": "Buyer", "3": "Driver", "4": "Farmer"}
    role_name = role_map.get(choice, "User")
    role_id = input(f"Enter {role_name} ID: ").strip()
    
    user = None
    if choice == "1": user = Coordinator(user_id, name, email, password, role_id)
    elif choice == "2": user = Buyer(user_id, name, email, password, role_id)
    elif choice == "3": 
        user = Driver(user_id, name, email, password, role_id, input("Vehicle Details: ").strip())
    elif choice == "4": 
        user = Farmer(user_id, name, email, password, role_id, input("Farm Name: ").strip(), input("Location: ").strip())
    
    if user:
        if user_id not in registered_users:
            registered_users[user_id] = {'user_id': user_id, 'name': name, 'email': email, 'password': password, 'roles': {}}
        else:
            registered_users[user_id]['password'] = password
            
        registered_users[user_id]['roles'][choice] = {'role_name': role_name, 'role_id': role_id, 'role_object': user}
        save_to_txt()
        print(f"\n[SUCCESS] Registered successfully as {role_name}!")

def login():
    if not registered_users: 
        print("\n[SYSTEM] No users registered. Please Sign Up first.")
        return None
    print("\n=== LOGIN ===")
    u_id = input("User ID: ").strip()
    pwd = input("Password: ").strip()
    
    if u_id in registered_users and registered_users[u_id]['password'] == pwd:
        return registered_users[u_id]
    
    print("\n[ERROR] Login failed. Incorrect ID or Password.")
    return None

def role_menu(user_info):
    """Main routing after successful login"""
    role_key = list(user_info['roles'].keys())[0]
    role_data = user_info['roles'][role_key]
    role_obj = role_data['role_object']

    print(f"\n[SYSTEM] Logged in as: {role_data['role_name']}")

    if role_key == "1": # Coordinator
        order_id = input("Enter Order ID to manage (e.g., 001): ").strip()
        coordinatormenu.show_coordinator_menu(role_obj, order_id)
    
    elif role_key == "2": # Buyer
        print("\nSelect Menu Mode:")
        print("1. Standard Buyer Menu")
        print("2. Run Module Test Cases (TC-01, TC-05, TC-06)")
        mode = input("\nChoice: ").strip()
        if mode == "2": 
            test_buyer_cases(role_obj)
        else: 
            buyermenu.show_buyer_menu(role_obj)
    
    elif role_key == "3": # Driver
        drivermenu.show_driver_menu(role_obj)
    
    elif role_key == "4": # Farmer
        produce_id = input("Enter Produce ID to update (e.g., P01): ").strip()
        farmermenu.show_farmer_menu(role_obj, produce_id)

def main():
    load_from_txt()
    while True:
        print("\n=== DIRECT FARM SYSTEM ===")
        print("1. Sign Up")
        print("2. Login")
        print("3. Exit")
        
        choice = input("\nEnter choice (1-3): ").strip()
        
        if choice == "1": 
            signup()
        elif choice == "2":
            user = login()
            if user: 
                role_menu(user)
        elif choice == "3":
            save_to_txt() 
            print("\nShutting down system... Goodbye!")
            break
        else:
            print("\n[INVALID] Please enter a valid option (1, 2, or 3).")

if __name__ == "__main__":
    main()

#Maininteractive
#Implemented by Jenx Yap Yee Xuan
#104527