class Report:
    def __init__(self, reportID, reportType, reportDate):
        self.__reportID = reportID
        self.__reportType = reportType
        self.__reportDate = reportDate

    # Getter
    def get_reportID(self):
        return self.__reportID
    
    def get_reportType(self):
        return self.__reportType
        
    def get_reportDate(self):
        return self.__reportDate

    # Behaviour Methods
    def generateReport(self):                                                       # Generate report and displays information
        print(f"[generateReport] Report ID: {self.__reportID}, "
              f"Type: {self.__reportType}, Date: {self.__reportDate} generated.")

    def viewReport(self):                                                           # Displays report details
        print(f"[viewReport] Viewing Report ID: {self.__reportID}, "
              f"Type: {self.__reportType}, Date: {self.__reportDate}")


def display_menu():
    print("\n=== Report Management System ===")
    print("1. Generate Report")
    print("2. View Report")
    print("3. Exit")


def main():
    reportID = input("Enter Report ID: ")
    reportType = input("Enter Report Type: ")
    reportDate = input("Enter Report Date (YYYY-MM-DD): ")

    report = Report(reportID, reportType, reportDate)

    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == "1":
            report.generateReport()

        elif choice == "2":
            report.viewReport()

        elif choice == "3":
            print("Exiting system.")
            break

        else:
            print("Invalid choice. Please try again.")

#Class Report
#Implemented by Afidz Izzudin Bin Abdul Mutalib
#103101