# Class Farmer
# Implemented by Mohammad Nabil Aiman bin Abdullah Abaang Safian | 105072

from user import User
from profile import Profile

class Farmer(User):
    def __init__(self, userID, name, email, password, farmerID, farmName, location):
        # INHERITANCE: Calling the parent (User) constructor
        super().__init__(userID, name, email, password)
        
        # ENCAPSULATION: Private attributes
        self.__farmerID = farmerID
        self.__farmName = farmName
        self.__location = location

        # ASSOCIATION: Farmer 'has a' Profile
        self.profile = Profile(farmerID, "", "")

    # Getter Methods
    def getFarmerID(self):
        return self.__farmerID
    
    def getFarmName(self):
        return self.__farmName
    
    def getLocation(self):
        return self.__location

    # POLYMORPHISM: Overriding the login method
    def login(self, password):
        print(f"Farmer {self.get_name()} is accessing the Farm Management Portal.")
        return super().login(password)  # MUST return True / False

    def manageProfile(self):
        print("Farmer profile managed.")

    def updateProduceDetails(self, produce_id):
        """Logic for TC-04"""
        print(f"\n[SYSTEM] Accessing Farm: {self.__farmName} ({self.__location})")
        print(f"Updating details for Produce ID: {produce_id}")
        
        # Exact output required for TC-04 verification
        print("Produce details updated.")
        return True

    def viewHarvestSchedule(self):
        print("Displaying harvest schedule...")

#Class Farmer
#Implemented by Mohammad Nabil Aiman bin Abdullah Abaang Safian
#105072