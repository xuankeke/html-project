# Main Interactive System for DirectFarm (Full Testing Version)
# Implemented by Jenx Yap Yee Xuan | ID: 104527

from farmer import Farmer
from buyer import Buyer
from coordinator import Coordinator
from driver import Driver
from payment import Payment
from report import Report
from produce import Produce 

import buyermenu
import farmermenu
import coordinatormenu
import drivermenu

USER_DATA_FILE = "users.txt"
registered_users = {}

# ================= FILE HANDLING =================

def save_to_txt():
    try:
        with open(USER_DATA_FILE, "w") as f:
            for user_id, info in registered_users.items():
                for role_key, role_data in info['roles'].items():
                    line = f"{info['user_id']}|{info['name']}|{info['email']}|{info['password']}|{role_key}|{role_data['role_id']}"
                    if role_key == "3": line += f"|{role_data['role_object'].vehicle}"
                    elif role_key == "4": line += f"|{role_data['role_object'].farmName}|{role_data['role_object'].location}"
                    f.write(line + "\n")
    except Exception as e:
        print(f"Error saving data: {e}")

def load_from_txt():
    global registered_users
    try:
        with open(USER_DATA_FILE, "r") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) >= 6:
                    u_id, name, email, pwd, r_key, r_id = parts[:6]
                    user_obj = None
                    if r_key == "1": user_obj = Coordinator(u_id, name, email, pwd, r_id)
                    elif r_key == "2": user_obj = Buyer(u_id, name, email, pwd, r_id)
                    elif r_key == "3": user_obj = Driver(u_id, name, email, pwd, r_id, parts[6])
                    elif r_key == "4": user_obj = Farmer(u_id, name, email, pwd, r_id, parts[6], parts[7])

                    if u_id not in registered_users:
                        registered_users[u_id] = {'user_id': u_id, 'name': name, 'email': email, 'password': pwd, 'roles': {}}
                    
                    role_map = {"1": "Coordinator", "2": "Buyer", "3": "Driver", "4": "Farmer"}
                    registered_users[u_id]['roles'][r_key] = {
                        'role_name': role_map[r_key],
                        'role_id': r_id,
                        'role_object': user_obj
                    }
    except FileNotFoundError:
        pass

# ================= CORE FUNCTIONS =================

def signup():
    print("\n=== SIGN UP ===")
    user_id = input("Enter User ID: ")
    name = input("Enter Name: ")
    email = input("Enter Email: ")
    password = input("Enter Password: ")
    
    print("\nSelect Your Role:")
    print("1. Coordinator")
    print("2. Buyer")
    print("3. Driver")
    print("4. Farmer")
    role_choice = input("Choice: ")
    
    role_map = {"1": "Coordinator", "2": "Buyer", "3": "Driver", "4": "Farmer"}
    role_name = role_map.get(role_choice, "User")
    role_id = input(f"Enter {role_name} ID: ")
    
    user = None
    if role_choice == "1": user = Coordinator(user_id, name, email, password, role_id)
    elif role_choice == "2": user = Buyer(user_id, name, email, password, role_id)
    elif role_choice == "3": user = Driver(user_id, name, email, password, role_id, input("Vehicle: "))
    elif role_choice == "4": user = Farmer(user_id, name, email, password, role_id, input("Farm Name: "), input("Location: "))
    
    if user:
        if user_id not in registered_users:
            registered_users[user_id] = {'user_id': user_id, 'name': name, 'email': email, 'password': password, 'roles': {}}
        registered_users[user_id]['roles'][role_choice] = {'role_name': role_name, 'role_id': role_id, 'role_object': user}
        save_to_txt()
        print(f"Successfully registered as {role_name}!")

def login():
    if not registered_users:
        print("No users registered yet.")
        return None
    
    print("\n=== LOGIN ===")
    u_id = input("Enter User ID: ")
    pwd = input("Enter Password: ")
    
    if u_id in registered_users and registered_users[u_id]['password'] == pwd:
        return registered_users[u_id]
    
    print("Invalid User ID or Password.")
    return None

# ================= ROLE MENU (SPLIT FOR TESTING) =================

def test_buyer_module(buyer_obj):
    """Handles Buyer Test Cases TC-01, TC-05, TC-06 separately"""
    while True:
        print("\n=== BUYER MODULE TESTING ===")
        print("1. [TC-01] Place New Order")
        print("2. [TC-05] Process Payment")
        print("3. [TC-06] Calculate Price (Overloading Scenarios)")
        print("0. Back to Main")
        
        choice = input("Select Test Choice: ")
        
        if choice == "1":
            order_id = input("Enter Order ID (e.g., P-99): ")
            buyer_obj.placeOrder(order_id)
            
        elif choice == "2":
            pay_id = input("Enter Payment ID (e.g., P-99): ")
            try:
                amt = float(input("Enter Amount (e.g., 1500): "))
                pay = Payment(pay_id, "2025-12-27", amt)
                pay.processPayment()
            except ValueError:
                print("Invalid input.")
                
        elif choice == "3":
            # Testing Overloading/Polymorphism Logic
            prod = Produce("P01", "Durian", "A", 0, 5.0)
            print("\nScenario A: No Discount (Weight 10)")
            prod.calculatePrice(weight=10) # Expected RM50
            
            print("\nScenario B: With RM10 Discount (Weight 10)")
            prod.calculatePrice(weight=10, discount=10) # Expected RM40
            print("Prices calculated correctly for both scenarios.")
            
        elif choice == "0":
            break

def role_menu(user_info):
    role_key = list(user_info['roles'].keys())[0]
    role_data = user_info['roles'][role_key]
    role_obj = role_data['role_object']

    if role_key == "1": # Coordinator
        order_id = input("Enter Order ID to manage: ")
        coordinatormenu.show_coordinator_menu(role_obj, order_id)
        
    elif role_key == "2": # Buyer
        test_buyer_module(role_obj)
        
    elif role_key == "3": # Driver
        drivermenu.show_driver_menu(role_obj)
        
    elif role_key == "4": # Farmer
        prod_id = input("Enter Produce ID to update: ")
        farmermenu.show_farmer_menu(role_obj, prod_id)

def main():
    load_from_txt()
    while True:
        print("\n=== DIRECT FARM SYSTEM ===")
        print("1. Sign Up")
        print("2. Login")
        print("3. Exit")
        
        choice = input("\nEnter your choice (1-3): ")
        
        if choice == "1": 
            signup()
        elif choice == "2":
            u = login()
            if u: 
                role_menu(u)
        elif choice == "3":
            print("Exiting System... Goodbye!")
            break
        else:
            print("Invalid choice. Please select 1, 2, or 3.")

if __name__ == "__main__":
    main()

#Main
#Implemented by Jenx Yap Yee Xuan
#104527