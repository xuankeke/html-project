# Class Produce
# Implemented by Vanessa Mennie Anak Jeffery (103005)

class Produce:
    def __init__(self, produceID, name, grade, weight, pricePerKg):
        # ENCAPSULATION: Private attributes
        self.__produceID = produceID
        self.__name = name
        self.__grade = grade
        self.__weight = weight                     
        self.__pricePerKg = pricePerKg

    def get_name(self):
        return self.__name

    # POLYMORPHISM (Method Overloading Simulation)
    # Allows calling with arguments (Testing) or without (Interactive)
    def calculatePrice(self, weight=None, discount=0):
        try:
            # 1. Check if values were passed as arguments (for TC-06)
            if weight is not None:
                calc_weight = float(weight)
                calc_discount = float(discount)
            # 2. Otherwise, ask for interactive input (for normal use)
            else:
                print(f"\n--- Price Calculation for {self.__name} ---")
                calc_weight = float(input(f"Enter weight for {self.__name} (kg): "))
                calc_discount = float(input("Enter discount amount (RM): "))

            # Math Logic
            base_total = self.__pricePerKg * calc_weight
            final_price = base_total - calc_discount
            
            # Print format required for TC-06 actual results
            print(f"Calculating for {self.__name}: Base RM{base_total:.2f} | Final RM{final_price:.2f}")
            
            return final_price
            
        except ValueError:
            print("[Error] Invalid numeric input.")
            return None

    def updateGrade(self):
        self.__grade = "Updated"
        print(f"Produce {self.__name} grade updated.")

    def updateWeight(self, new_weight):
        if new_weight < 0:
            print("Weight cannot be negative.")
            return
        self.__weight = new_weight
        print(f"Produce weight updated to {new_weight}kg.")
        
#Class Produce
#Implemented by Vanessa Mennie Anak Jeffery
#103005