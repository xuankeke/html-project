class User:
    def __init__(self, userID, name, email, password):
        self.__userID = userID
        self.__name = name
        self.__email = email
        self.__password = password #Private and protected attribute (no getter)

    # Getter 
    def get_userID(self):
        return self.__userID
    
    def get_name(self):
        return self.__name
    
    def get_email(self):
        return self.__email

    # Behaviour method
    def signup(self):
        print(f"User {self.__name} signed up successfully.")

    def login(self, userID, name, email, password):
        """Login requires ID, name, email, and password - all must match"""
        if (str(userID) == str(self.__userID) and 
            name.lower() == self.__name.lower() and 
            email.lower() == self.__email.lower() and 
            password == self.__password):
            print("Access Granted.")
            return True
        else:
            print("Access Denied.")
            return False
        
    def logout(self):
        print(f"User {self.__name} logged out successfully.")

    def updatePassword(self, old_password, new_password):
        """Update password when user knows old password"""
        if old_password == self.__password:
            self.__password = new_password
            print("Password updated successfully.")
            return True
        else:
            print("Old password is incorrect.")
            return False
    
    def resetPassword(self, userID, name, email, new_password):
        """Reset password if user forgot - verifies ID, name, and email"""
        if (str(userID) == str(self.__userID) and 
            name.lower() == self.__name.lower() and 
            email.lower() == self.__email.lower()):
            self.__password = new_password
            print("Password reset successfully.")
            return True
        else:
            print("Access Denied. User ID, Name, or Email does not match.")
            return False
        
#Class User
#Implemented by Jenx Yap Yee Xuan
#104527