# coordinatormenu.py
# Corrected signature to match maininteractive.py call

def show_coordinator_menu(current_coordinator, order_id):
    """
    Coordinator Menu: Receives order_id from the main system.
    """
    # Removed the redundant 'order_id = input()' line because 
    # the ID is now passed in as an argument.

    while True:
        print(f"\n==============================")
        print(f"   COORDINATOR: ORDER {order_id}   ")
        print("==============================")
        print("1. Confirm order and final details")
        print("2. [TC-02] Record produce weight")
        print("3. Record produce grade")
        print("4. Generate and view system report")
        print("5. Update account password")
        print("6. Logout")
        print("------------------------------")
        
        choice = input("Please select an option (1-6): ").strip()

        if choice == '1':
            # TC-02 Logic
            current_coordinator.confirmOrder()
            
        elif choice == '2':
            current_coordinator.recordWeight(order_id)
            
        elif choice == '3':
            current_coordinator.recordGrade()
            
        elif choice == '4':
            current_coordinator.generateReport()
            
        elif choice == '5':
            # If your class has this method
            if hasattr(current_coordinator, 'updatePassword'):
                current_coordinator.updatePassword()
            else:
                print("[System] Password update feature coming soon.")
            
        elif choice == '6':
            print(f"Logged out from Order {order_id} management.")
            break 
            
        else:
            print("[Error] Invalid selection. Please try again.")

#Coordinator Menu
#Implemented by Jenx Yap Yee Xuan
#104527