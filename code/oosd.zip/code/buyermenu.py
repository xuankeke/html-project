# buyermenu.py
from payment import Payment

def show_buyer_menu(current_buyer):
    """
    Displays the Buyer menu. 
    Processes Price Calculation and Payment immediately after placing an order.
    """
    while True:
        print("\n==============================")
        print("      BUYER CONTROL PANEL      ")
        print("==============================")
        print("1. Place Order")
        print("2. View Current Order")
        print("3. View Payment History")
        print("4. Process payment")
        print("5. Update Account Password")
        print("6. Logout")
        print("------------------------------")
        
        choice = input("Select an option: ")

        if choice == '1':
            # --- STEP 1: PLACE ORDER ---
            # Input Produce ID first as requested
            produce_id = input("\nEnter Produce ID to order: ")
            current_buyer.placeOrder(produce_id)
            
            # --- STEP 2: CALCULATE PRICE ---
            # Input weight and discount interactively
            print("\n--- Price Calculation ---")
            try:
                weight = float(input(f"Enter weight for {produce_id} (kg): "))
                discount = float(input("Enter discount amount (RM): "))
                
                # Assuming the Buyer class has access to calculation logic or the Produce object
                # This mimics the Produce.calculatePrice() logic
                base_price_per_kg = 10.0  # Example base price
                base_total = base_price_per_kg * weight
                final_price = base_total - discount
                
                print(f"Base Total: RM {base_total:.2f}")
                print(f"Final Price after Discount: RM {final_price:.2f}")

                # --- STEP 3: PROCESS PAYMENT ---
                # Triggered automatically after calculation
                print("\n--- Payment Processing ---")
                pay_id = input("Enter Payment ID: ")
                
                # Creating Payment object and processing
                pay = Payment(pay_id, "2026-01-06", final_price)
                pay.processPayment()
                print("Payment Processed Successfully!")
                
            except ValueError:
                print("[Error] Invalid numeric input for weight or discount.")

        elif choice == '2':
            current_buyer.viewOrder()

        elif choice == '3':
            current_buyer.viewPaymentHistory()

        elif choice == '4':
            current_buyer.processPayment()

        elif choice == '5':
            current_buyer.updatePassword()

        elif choice == '6':
            current_buyer.logout()
            print("Logging out... Returning to Main Entry.")
            break 

        else:
            print("Invalid choice. Please try again.")

#BuyerMenu
#Implemented by Jenx Yap Yee Xuan
#104527