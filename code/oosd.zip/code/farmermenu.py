# farmermenu.py
# Updated to accept 'produce_id' from maininteractive.py

def show_farmer_menu(current_farmer, produce_id):
    """
    Farmer Menu: Receives produce_id from the main system.
    """
    while True:
        print(f"\n==============================")
        print(f"    FARMER: PRODUCE {produce_id}    ")
        print("==============================")
        print("1. [TC-04] Update produce details")
        print("2. Add new produce")
        print("3. View harvest schedule")
        print("4. Manage farmer profile")
        print("5. Logout")
        print("------------------------------")
        
        choice = input("Please select an option (1-5): ").strip()

        if choice == '1':
            # This calls the method in farmer.py and passes the ID
            current_farmer.updateProduceDetails(produce_id)
            
        elif choice == '2':
            print("\n[SYSTEM] Feature to add new produce is under development.")
            
        elif choice == '3':
            current_farmer.viewHarvestSchedule()
            
        elif choice == '4':
            current_farmer.manageProfile()
            
        elif choice == '5':
            print(f"Logging out from Produce {produce_id} management...")
            break 
            
        else:
            print("[Error] Invalid selection. Please try again.")

#FarmerMenu
#Implemented by Jenx Yap Yee Xuan
#104527