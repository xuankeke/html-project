# driver_menu.py

def show_driver_menu(current_driver):
    """
    Displays the Driver menu and routes user input to Driver class methods.
    :param current_driver: An instance of the Driver class
    """
    while True:
        print("\n==============================")
        print("       DRIVER MAIN MENU       ")
        print("==============================")
        print("1. Calculate transport costs for an order")
        print("2. [TC-03]Confirm delivery for an order")
        print("3. Update account password")
        print("4. Logout")
        print("------------------------------")
        
        choice = input("Please select an option (1-4): ")

        if choice == '1':
            # This method likely requires an order object or ID as a parameter
            current_driver.calculateTransportCost()
            
        elif choice == '2':
            current_driver.confirmDelivery()
            
        elif choice == '3':
            current_driver.updatePassword()
            
        elif choice == '4':
            current_driver.logout()
            break  # Exit the loop to return to maininteractive.py
            
        else:
            print("[Error] Invalid selection. Please try again.")

#DriverMenu
#Implemented by Jenx Yap Yee Xuan
#104527