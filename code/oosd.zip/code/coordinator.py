# Class Coordinator
# Implemented by Zechariah Vieri Anak Sari | ID: 106772

from user import User

class Coordinator(User):
    def __init__(self, userID, name, email, password, coordinatorID):
        # INHERITANCE: Calling parent (User) constructor
        super().__init__(userID, name, email, password)  
        self.__coordinatorID = coordinatorID

    # Getter
    def get_coordinatorID(self):
        return self.__coordinatorID

    # Behaviour Methods
    def confirmOrder(self):
        print("Order confirmed by Coordinator.")

    # FIX: Added 'order_id' parameter so the method can receive the ID
    def recordWeight(self, order_id):
        """Logic for TC-02"""
        print(f"\n[SYSTEM] Recording weight for Order: {order_id}")
        print("Produce weight recorded.") # <--- Exact output for TC-02
        return True

    def recordGrade(self):
        print("Produce grade recorded.")

    def approveProduceWeight(self):
        print("Produce weight approved by Coordinator.")

    def rejectProduceWeight(self):
        print("Produce weight rejected by Coordinator.")

    def generateReport(self):
        print("System report generated.")

    def viewReport(self):
        print("Viewing system report.")

#Class Coordinator
#Implemented by Zechariah Vieri Anak Sari
#106772