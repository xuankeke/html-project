class Order:
    def __init__(self, orderID, orderDate, totalAmount):
        self.__orderID = orderID
        self.__orderDate = orderDate
        self.__orderStatus = "Pending"         # initial status for the order
        self.__totalAmount = totalAmount

    # Getter
    def get_orderID(self):
        return self.__orderID
    
    def get_orderDate(self):
        return self.__orderDate
    
    def get_orderStatus(self):
        return self.__orderStatus
    
    def get_totalAmount(self):
        return self.__totalAmount

    # Behaviour methods
    def createOrder(self):
        self.__orderStatus = "Pending"
        print("Order created successfully.")
        print("Order ID      :", self.__orderID)
        print("Order Date    :", self.__orderDate)
        print("Total Amount  : RM", self.__totalAmount)
        print("Order Status  :", self.__orderStatus)

    def updateOrderStatus(self, newStatus):      
        # demonstrates encapsulation by controlling how the status is modified
        # accepts a new status as a parameter
        self.__orderStatus = newStatus
        print("Order status updated to:", self.__orderStatus)

    def cancelOrder(self):
        # checks if the order is already cancelled before updating
        # this ensures proper control over order status
        if self.__orderStatus == "Cancelled":
            print("Order is already cancelled.")
        else:
            self.__orderStatus = "Cancelled"
            print("Order cancelled successfully.")

#Class Order
#Implemented by Vanessa Mennie Anak Jeffery
#103005